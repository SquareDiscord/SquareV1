# SquareV1



Hello! This is Square Version 1, This code was last edited 6 months ago, Do what you will with this code, Please credit us where credit is due!

If you need any help I can try to help you, just contact me on discord: Python#0001
